import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-documents-item',
  templateUrl: './documents-item.component.html',
  styleUrls: ['./documents-item.component.css']
})
export class DocumentsItemComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
